package com.example.betterproj;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
    }

    public void startHydra(View view) {

        EditText editText;
        editText = (EditText) findViewById(R.id.textInputEditText3);
        String username = (editText.getText()).toString();
        editText = (EditText) findViewById(R.id.textInputEditText4);
        String password = (editText.getText()).toString();
        editText = (EditText) findViewById(R.id.textInputEditText5);
        String ipAddress = (editText.getText()).toString();
        editText = (EditText) findViewById(R.id.textInputEditText6);
        String protocol = (editText.getText()).toString();

        String cmd = "hydra -l " + username + " -p " + password + " " + ipAddress + " " + protocol;

        showHydra(cmd);
    }

    public void showHydra(String cmd) {

        MainActivity m = new MainActivity();
        setContentView(R.layout.activity_main2);
        TextView textView = (TextView) findViewById(R.id.textView);
        textView.setText(m.RunCommand(cmd));
    }

}