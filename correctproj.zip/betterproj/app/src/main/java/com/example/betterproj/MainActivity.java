package com.example.betterproj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Intent i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    static String RunCommand(String cmd) {

        StringBuffer cmdOut = new StringBuffer();
        Process process;
        try {
            process = Runtime.getRuntime().exec(cmd);
            InputStreamReader r = new InputStreamReader(process.getInputStream()); //mount -o rw,remount /system
            BufferedReader bufReader = new BufferedReader(r);
            char[] buf = new char[4096];
            int nRead = 0;
            while ((nRead = bufReader.read(buf)) > 0) {
                Log.i("ligmk", buf.toString());
                cmdOut.append(buf, 0, nRead);
            }
            bufReader.close();
            try {
                process.waitFor();
            } catch (InterruptedException e) {
                cmdOut.append(e.getStackTrace());
                Log.i("gggg", e.toString());
            }
        } catch (IOException e) {
            cmdOut.append(e.getStackTrace());
            Log.i("ffff", e.toString());
        }
        Log.i("Bit", cmdOut.toString());
//        try {
//            process = Runtime.getRuntime().exec("su");
//            InputStreamReader r = new InputStreamReader(process.getInputStream());
//            BufferedReader bufReader = new BufferedReader(r);
//            DataOutputStream os = new DataOutputStream(process.getOutputStream());
//            os.writeBytes(cmd);
//            os.flush();
//
//        }
//        catch (Exception e) {
//            Log.i("jjjjjj", e.toString());
//        }
        return cmdOut.toString();
    }

    public void runNmap(View view) {
        i = new Intent(this, MainActivity3.class);
        startActivity(i);
    }


    public void runHydra(View view) {
        i = new Intent(this, MainActivity4.class);
        startActivity(i);
    }

    public void runIfconfig(View view) {
        i = new Intent(this, MainActivity5.class);
        startActivity(i);
    }
}