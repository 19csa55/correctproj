package com.example.betterproj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {

    Intent i;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
    }

    public void startNmap(View view) {

        EditText editText = (EditText) findViewById(R.id.textInputEditText2);
        String val = (editText.getText()).toString();
        editText = (EditText) findViewById(R.id.textInputEditText);
        String ipAddress = String.valueOf(editText.getText());
        String cmd = "nmap " + val + "/" + ipAddress;

        showNmap(cmd);
    }

    public void showNmap(String cmd) {

        MainActivity m = new MainActivity();
        setContentView(R.layout.activity_main2);
        TextView textView = (TextView) findViewById(R.id.textView);
        //String[] commandAndArgs = new String[]{"su", "-c", "'{/data/data/com.termux/files/usr/bin/ls, /data}'"};///data/data/com.termux/files/usr/bin/ls
        cmd = "su -c '/data/data/com.termux/files/usr/bin/nmap'"; //chmod 777 /data/data/com.\eqwadstermux/files/usr/bin/ifconfig

        //cmd = "/data/data/com.termux/files/usr/bin/sudo ls";
        textView.setText(m.RunCommand(cmd));//[Ljava.lang.StackTraceElement;@3841fb1
    }
}